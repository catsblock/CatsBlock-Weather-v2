# CatsBlock's Weather

Material You (Material 3) weather app for Android built with Kotlin and Jetpack Compose. Package `com.catsblock.weather`, launcher name `Weather`.

## Build

1. Open the folder in Android Studio (JDK 17) and let it sync, or run `gradle assembleRelease` with Gradle 8.11.1.
2. Optional: set `ACCUWEATHER_API_KEY` in `gradle.properties`, as an environment variable, or later inside the app under Settings.
3. The APK is written to `app/build/outputs/apk/release/com.catsblock.weather-release.apk`.

GitHub Actions (`.github/workflows/build.yml`) builds the APK on every push. Add the repository secret `ACCUWEATHER_API_KEY` to bake your key in.

## Data sources

- AccuWeather: current conditions and alerts (needs a key).
- Open-Meteo: forecast, hourly data, air quality, UV and geocoding (no key). It also provides everything when no AccuWeather key is set.
- Google Translate free endpoint: translates external text to English.
- Windy embed: keyless radar layers. Layers without a dedicated public feed use the closest Windy overlay.
- Google Weather icon set from `mrdarrengriffin/google-weather-icons`.
